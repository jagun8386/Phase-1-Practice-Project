package Session3;

	class OurException extends Exception 
	{ 
	    public OurException(String s) 
	    { 
	        super(s); 
	    } 
	} 
	public class Customexceptions 
	{ 
	    public static void main(String args[]) 
	    { 
	        try
	        { 
	            throw new OurException("temp"); 
	        } 
	        catch (OurException ex) 
	        { 
	            System.out.println("Caught"); 
	            System.out.println(ex.getMessage()); 
	        } 
	    } 
	}


