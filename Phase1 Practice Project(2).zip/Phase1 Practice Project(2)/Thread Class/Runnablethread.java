package session2;

public class Runnablethread implements Runnable {
		
		public  void run() {
			
			for(int i=1; i<5; i++) {
				
				System.out.println(i+ " "+Thread.currentThread().getName());
			
				 try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
				
			}
			
			
			 
		}
		
		
		public static void main(String[] args) {
			
			
			Runnablethread ins1= new Runnablethread();
			Runnablethread ins2= new Runnablethread();
			
			Thread t1=new  Thread(ins1);
			Thread t2=new  Thread(ins2);
			
			t1.setName("Thread");
			t2.setName("main thread");
		
			t1.start();
			t2.start();
		}

	}
