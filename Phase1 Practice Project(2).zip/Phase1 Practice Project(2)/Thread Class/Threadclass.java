package session2;

public class Threadclass extends Thread {
		
		public void run() {
			System.out.println("thread Started");
		}
		
		public static void main(String[] args) {
			
			Threadclass t1= new Threadclass();
			Threadclass t2= new  Threadclass();
			
			t1.start();
			t2.start();
		}

	}

