package session2;

public class Sleepwaitpg {
		
		private static Object LOCK= new Object();
		
		public static void main(String[] args) {
			
		
				try {
					
					Thread.sleep(5000);
					System.out.println(Thread.currentThread().getName()+ " is  woke up after "
							+ "5 second  of  sleep");
					
					synchronized (LOCK) {
						LOCK.wait(9000);
						System.out.println("Object is woke up after wait of  9 seconds");
						
					}
					
					
					
				} catch (InterruptedException e) {
					
					e.printStackTrace();
					
					System.out.println("Error Occured: "+e);
				}
			
			
		}

	}


