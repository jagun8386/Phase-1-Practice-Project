package com.simplilearn.demo;

public class AuthenticationUser {
	public String username()
	{
String email = "jagan@gmail.com";
		return email;
	}
	public String paswd()
	{
		String password = "jagan";
		return password;
	}
}

