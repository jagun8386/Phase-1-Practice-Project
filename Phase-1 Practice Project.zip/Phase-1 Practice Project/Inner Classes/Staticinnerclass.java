package interferencecollection;

public class Staticinnerclass {
static class A{
	public static void hello() {
		System.out.println("static inner class");
	}
}
public static void main(String[]args) {
	Staticinnerclass.A s=new Staticinnerclass.A();
	s.hello();
}
}
