package interferencecollection;

public class Memberinnerclass {
	private String message="hello";
	class Inner{
		void hello() {
			System.out.println("member inner class");
		}
	}
	public static void main(String[]args) {
		Memberinnerclass m=new Memberinnerclass();
		System.out.println(m.message);
		Memberinnerclass.Inner innerm=m.new Inner();
		innerm.hello();
	}

}
