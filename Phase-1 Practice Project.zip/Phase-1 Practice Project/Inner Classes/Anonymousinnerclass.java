package interferencecollection;

abstract class AnonymousInner {
	abstract void test();
}
public class Anonymousinnerclass{
	public static void main(String[]args) {
		AnonymousInner i=new AnonymousInner() {
			public void test() {
				System.out.println("Anonymous Inner Class");
			}
		};
		i.test();
		
	}

}
