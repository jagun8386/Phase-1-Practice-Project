package interferencecollection;

public class Localinnerclass {
private String msg="inner class";
void test()
{
	class Inner{
		void local() {
			System.out.println("Inside Local Class");
			System.out.println(msg);
			}
	}
	Inner obj=new Inner();
	obj.local();
}
public static void main(String[]args) {
	Localinnerclass l=new Localinnerclass();
	l.test();
	
}
}
