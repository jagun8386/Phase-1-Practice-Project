package assistedprojects1;
import assistedprojects.*;

public class Public1 {
	public static void main(String[]args)
	{
		publicaccessspecifier obj=new publicaccessspecifier();
		obj.display();
		
	}
}
