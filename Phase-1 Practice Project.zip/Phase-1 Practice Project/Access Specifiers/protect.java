package assistedprojects1;
import assistedprojects.*;

public class protect extends protectedaccessspecifier{
	public static void main(String[]args) {
		protect obj=new protect();
		obj.display();
		
	}

}
