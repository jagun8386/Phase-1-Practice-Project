package assistedprojects;

public class protectedaccessspecifier
{
	protected void display()
	{
		System.out.println("this is protected access specifier");
	}

}
