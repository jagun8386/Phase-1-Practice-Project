package interferencecollection;

import java.util.ArrayList;
import java.util.Iterator;

public class ArraylistDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> a=new ArrayList<String>();

		System.out.println("Size:"+a.size());
		a.add("red");
		a.add("green");
		a.add("orange");
		a.add("yellow");
		System.out.println(a);
		a.add(1,"pink");
		a.add(0,"violet");
		System.out.println(a);
		a.remove(3);
		System.out.println(a);
		System.out.println("After Adding an Elements :"+a.size());
		a.add(null);// list contains null value
		
		System.out.println("After Adding null Element :"+a.size());
		System.out.println(a);

		System.out.println("List Contains grey? :"+a.contains("grey"));
         a.remove(null);
         System.out.println(a.get(2));
		System.out.println(a);
		Iterator<String> itr=a.iterator();
		while(itr.hasNext())
		{
		System.out.println(itr.next());
		}
		a.ensureCapacity(10);
	    for(String s:a){
			System.out.println(a);
		}
		System.out.println(a.isEmpty());
	}

}
