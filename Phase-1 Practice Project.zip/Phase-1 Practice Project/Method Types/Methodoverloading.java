package assistedprojects;

public class Methodoverloading {
	int multiply(int a, int b) {
		return a*b;
	}
	int subtract(int a, int b) {
		return a-b;
	}
	float add(float a, float b) {
		return a+b;
	}
	
	double multiply(double a, double b) {
		return a*b;
	}
	
	 
	
	public static void main(String[] args) {
		Methodoverloading obj= new Methodoverloading();
		System.out.println("Multiplication is:"+obj.multiply(2,3));
		System.out.println("Subtraction is :"+obj.subtract(10,5));
		System.out.println("Addition is :"+obj.add(1,4));
		System.out.println("Multiplication is: "+obj.multiply(4,6));
		
	}
}
