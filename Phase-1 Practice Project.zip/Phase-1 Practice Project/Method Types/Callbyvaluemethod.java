package assistedprojects;

public class Callbyvaluemethod {

int num=20;

void operation(int num) {
	this.num=num*10/100;
}
public static void main(String[] args) {
	
	Callbyvaluemethod obj= new Callbyvaluemethod();
	
	System.out.println("Value before function call: "+obj.num);
	
	obj.operation(100);
	System.out.println("Value after function call: "+obj.num);
}
}
