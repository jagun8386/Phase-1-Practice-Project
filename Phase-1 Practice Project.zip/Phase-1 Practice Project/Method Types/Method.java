package assistedprojects;

public class Method {
	public int multiplynumbers(int a,int b) {
		int c=a*b;
		return c;
	}

	public static void main(String[] args) {

		Method obj=new Method();
		int ans=obj.multiplynumbers(5, 2);
		System.out.println("Multipilcation is :"+ans);
		}


}
