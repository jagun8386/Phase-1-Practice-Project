package interferencecollection;

class Constructor{
	protected Constructor(){
		System.out.println("zero parameter constructor");
	}
	void display() {
		System.out.println("default display method");
	}
}
public class DefaultConstructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Constructor c=new Constructor();
c.display();
	}

}
