package interferencecollection;
public class Stringbuild_buffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
		
		String str = "Hello"; 
        
        // conversion from String object to StringBuffer 
        StringBuffer sb = new StringBuffer(str); 
        sb.append(" world");
        sb.reverse(); 
        System.out.println("String to StringBuffer");
        System.out.println(sb); 
          
        System.out.println("Size: "+sb.length());
		
		sb.append("Welcome");
		System.out.println(sb);
		
		sb.insert(11, " ");
		System.out.println(sb);
		
		sb.replace(12, 19, "Bye");
		System.out.println(sb);
	
       
        // conversion from String object to StringBuilder 
        StringBuilder sb1 = new StringBuilder(str); 
        sb1.append(" world"); 
        System.out.println("String to StringBuilder");
        System.out.println(sb1);  
          System.out.println("Size: "+sb1.length());
		
		sb1.append("Welcome");
		System.out.println(sb1);
		
		sb1.insert(11, " ");
		System.out.println(sb1);
		
		sb1.replace(12, 19, "Bye");
		System.out.println(sb1);
		
		sb1.reverse();
		System.out.println(sb1);

	}

}

